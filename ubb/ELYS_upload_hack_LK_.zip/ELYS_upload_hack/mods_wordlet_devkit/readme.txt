#############################################
# Script: Mods Wordlet Install DevKit v0.1
# Author: Daniel Khodaparast (DPK)
# Email: dpk@nfscheats.com
#############################################
# Idea for vars_wordlets_mods derived from 
# AllenAyres and Leshrac.
#############################################
# Note: Backup your files! Report any bugs.
#############################################



#############################################
# Dev Kit Instructions
#############################################

1. The files that you need to include with
your hack/mod are:

- mod_wordlet_install.txt
- vars_wordlets_mods.cgi


2. You need to change the following things in
mod_wordlet_install.txt before distributing 
it.  In step 2, for each wordlet your mod/hack
uses, define it using:

<!hackname!>_<!key!> => "<!wordlet!>",

Replace the <!hackname!> with your hack/mods
name.  It could be a short/long version of it,
doesnt really matter as long as all of your
wordlets use that!  The <!key!> describes 
what the wordlet is for and <!wordlet!> is 
the actual wordlet text itself.  Remember to
also add these same wordlets to the file
vars_wordlets_mods.cgi too.

3. Find step 4, in mod_wordlet_install.txt, 
and change <!hackname!> to your hack/mods 
install txt name.

4. Done! You are now ready to distribute 
the files:

- mod_wordlet_install.txt
- vars_wordlets_mods.cgi

...with your mod.  You will need to repeat 
these instructions if you add/remove/change
wordlets with your hack/mod in the future.


#############################################
# Save, Done